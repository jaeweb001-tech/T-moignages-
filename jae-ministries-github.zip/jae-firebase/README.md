# JAE Ministries — Site de Recueil de Témoignages

Site professionnel de collecte de témoignages, hébergé gratuitement sur **Firebase Hosting** + **Firestore** + **Authentication**.

**Projet Firebase :** `jaetemoignage`  
**Email Admin :** `jaeweb001@gmail.com`

---

## Ce que contient ce dépôt

```
jae-firebase/
├── public/                    ← Fichiers du site (à déployer)
│   ├── index.html             ← Page publique
│   ├── admin.html             ← Espace administrateur
│   ├── css/style.css
│   ├── js/
│   │   ├── firebase-config.js ← Config déjà remplie avec tes clés
│   │   ├── app.js
│   │   └── admin.js
│   └── img/logo.jpg
├── firestore.rules            ← Règles de sécurité
├── firebase.json
├── .firebaserc
└── README.md
```

---

## Étapes obligatoires avant le premier déploiement

### 1. Activer Authentication (si pas encore fait)

1. Ouvre [Firebase Console](https://console.firebase.google.com/project/jaetemoignage)
2. Menu de gauche → **Build → Authentication**
3. Clique sur **Get started**
4. Onglet **Sign-in method** → active **Email/Password** → Enregistrer

### 2. Créer le compte Admin

1. Toujours dans **Authentication** → onglet **Users**
2. Clique sur **Add user**
3. **Email** : `jaeweb001@gmail.com`
4. **Mot de passe** : choisis un mot de passe fort (ex: `JaeMin2026!Secure`)
5. Clique sur **Add user**

> Tu utiliseras cet email + mot de passe pour te connecter sur `/admin.html`

### 3. Créer Firestore Database (si pas encore fait)

1. Menu → **Build → Firestore Database**
2. **Create database**
3. Choisis **Start in production mode**
4. Localisation recommandée : `eur3 (Europe)` ou la plus proche
5. Clique sur **Enable**

### 4. Publier les règles de sécurité

1. Dans Firestore → onglet **Rules**
2. Copie **tout** le contenu du fichier `firestore.rules` de ce projet
3. Colle-le et clique sur **Publish**

---

## Déploiement avec GitHub + Firebase

### A. Mettre le code sur GitHub

1. Crée un nouveau dépôt sur GitHub (ex: `jae-temoignages`)
2. Sur ton ordinateur :

```bash
# Clone le dépôt vide que tu viens de créer
git clone https://github.com/TON-USERNAME/jae-temoignages.git
cd jae-temoignages

# Copie TOUT le contenu de ce dossier (jae-firebase) dedans
# Puis :
git add .
git commit -m "Site JAE Ministries - première version"
git push origin main
```

### B. Déployer sur Firebase Hosting

Sur ton ordinateur (une seule fois) :

```bash
# Installer Firebase CLI
npm install -g firebase-tools

# Se connecter à ton compte Google
firebase login

# Aller dans le dossier du projet
cd jae-temoignages

# Lier au projet Firebase (déjà configuré dans .firebaserc)
firebase use jaetemoignage

# Déployer les règles + le site
firebase deploy
```

Après le déploiement réussi, ton site sera en ligne sur :

- **https://jaetemoignage.web.app**
- ou **https://jaetemoignage.firebaseapp.com**

Page admin : **https://jaetemoignage.web.app/admin.html**

---

## Déploiement automatique depuis GitHub (optionnel)

Tu peux configurer un déploiement automatique à chaque `git push` plus tard via GitHub Actions.  
Pour l’instant, la méthode `firebase deploy` ci-dessus est la plus simple et fiable.

---

## Fonctionnalités

| Fonctionnalité | Statut |
|---------------|--------|
| Formulaire public (nom + WhatsApp facultatifs) | ✅ |
| Genre obligatoire (Homme / Femme) | ✅ |
| Témoignage max 5000 mots | ✅ |
| Message de remerciement chrétien | ✅ |
| Admin sécurisé (email + mot de passe) | ✅ |
| Numérotation séquentielle | ✅ |
| Suppression auto après 20 jours | ✅ |
| Design professionnel noir & or | ✅ |
| 100 % gratuit | ✅ |

---

## Sécurité

- Seul `jaeweb001@gmail.com` peut se connecter et lire les témoignages
- Personne ne peut modifier un témoignage
- Les règles Firestore bloquent toute lecture non autorisée
- Les clés API sont publiques (c’est normal) — la vraie sécurité est dans les règles + Auth

---

## Commandes utiles

```bash
# Déployer uniquement le site
firebase deploy --only hosting

# Déployer uniquement les règles
firebase deploy --only firestore:rules
```

---

Que Dieu bénisse abondamment l’œuvre de **JAE Ministries** !
