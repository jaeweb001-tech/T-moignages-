// JAE Ministries - Formulaire de témoignage (Firebase)

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('temoignage-form');
    const textarea = document.getElementById('temoignage');
    const wordCountEl = document.getElementById('word-count');
    const thankYou = document.getElementById('thank-you');
    const thankMessage = document.getElementById('thank-message');
    const submitBtn = document.getElementById('submit-btn');
    const btnNew = document.getElementById('btn-new');

    // Compteur de mots
    function countWords(text) {
        return (text.trim().match(/\b\w+\b/gu) || []).length;
    }

    textarea.addEventListener('input', () => {
        const count = countWords(textarea.value);
        wordCountEl.textContent = count;
        wordCountEl.parentElement.classList.toggle('over', count > 5000);
    });

    // Soumission du témoignage
    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const genreInput = form.querySelector('input[name="genre"]:checked');
        if (!genreInput) {
            alert('Veuillez sélectionner votre genre (Homme ou Femme).');
            return;
        }

        const temoignage = textarea.value.trim();
        if (!temoignage) {
            alert('Veuillez écrire votre témoignage.');
            return;
        }

        if (countWords(temoignage) > 5000) {
            alert('Le témoignage ne doit pas dépasser 5000 mots.');
            return;
        }

        // UI loading
        submitBtn.disabled = true;
        submitBtn.querySelector('.btn-text').style.display = 'none';
        submitBtn.querySelector('.btn-loading').style.display = 'inline';

        try {
            // 1. Obtenir le prochain numéro d'ordre de façon atomique
            const compteurRef = db.collection('compteurs').doc('ordre');
            
            let nouvelOrdre = 1;
            
            await db.runTransaction(async (transaction) => {
                const doc = await transaction.get(compteurRef);
                if (doc.exists) {
                    nouvelOrdre = (doc.data().valeur || 0) + 1;
                }
                transaction.set(compteurRef, { valeur: nouvelOrdre }, { merge: true });
            });

            // 2. Créer le témoignage
            const data = {
                ordre: nouvelOrdre,
                genre: genreInput.value,
                temoignage: temoignage,
                createdAt: firebase.firestore.FieldValue.serverTimestamp(),
                // Optionnels
                nom: document.getElementById('nom').value.trim() || null,
                whatsapp: document.getElementById('whatsapp').value.trim() || null
            };

            await db.collection('temoignages').add(data);

            // Message de remerciement
            form.style.display = 'none';
            thankYou.style.display = 'block';
            thankMessage.textContent = 
                "Merci beaucoup pour votre témoignage ! Que Dieu vous bénisse abondamment et accomplisse encore de merveilleux miracles dans votre vie. Votre partage est précieux pour l'œuvre de JAE Ministries.";

        } catch (err) {
            console.error('Erreur envoi:', err);
            alert('Une erreur est survenue lors de l\'envoi. Veuillez réessayer dans quelques instants.');
        } finally {
            submitBtn.disabled = false;
            submitBtn.querySelector('.btn-text').style.display = 'inline';
            submitBtn.querySelector('.btn-loading').style.display = 'none';
        }
    });

    // Nouveau témoignage
    btnNew.addEventListener('click', () => {
        form.reset();
        wordCountEl.textContent = '0';
        wordCountEl.parentElement.classList.remove('over');
        form.style.display = 'block';
        thankYou.style.display = 'none';
    });

    // Smooth scroll
    document.querySelectorAll('a[href="#temoignage"]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('temoignage').scrollIntoView({ behavior: 'smooth' });
        });
    });
});
